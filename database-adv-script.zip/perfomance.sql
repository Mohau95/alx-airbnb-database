-- Task 4: Optimize Complex Queries

-- Initial query: Retrieve bookings with user, property, and payment details
SELECT 
    b.id AS booking_id,
    u.name AS user_name,
    p.name AS property_name,
    pay.amount AS payment_amount
FROM bookings b
JOIN users u ON b.user_id = u.id
JOIN properties p ON b.property_id = p.id
JOIN payments pay ON b.id = pay.booking_id;

-- Optimized version (indexes should make this faster):
-- Ensure indexes exist on bookings.user_id, bookings.property_id, payments.booking_id
