-- Task 3: Implement Indexes for Optimization

-- Create indexes on frequently used columns
CREATE INDEX idx_users_id ON users(id);
CREATE INDEX idx_bookings_user_id ON bookings(user_id);
CREATE INDEX idx_bookings_property_id ON bookings(property_id);
CREATE INDEX idx_properties_id ON properties(id);
CREATE INDEX idx_reviews_property_id ON reviews(property_id);

-- Measure performance before and after using:
-- EXPLAIN SELECT ... or ANALYZE SELECT ...
